import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import Qyrexobf from './core/index.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 10000;

app.disable('x-powered-by');
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, 'public'), {
  maxAge: '1h',
  etag: true
}));

app.get('/health', (_req, res) => {
  res.json({ ok: true, service: 'Qyrexobf', version: '2.0.0' });
});

app.get('/api/presets', (_req, res) => {
  res.json({
    presets: ['Low', 'Medium', 'High', 'Ultra'],
    default: 'Medium'
  });
});

app.post('/api/obfuscate', (req, res) => {
  try {
    const body = req.body || {};
    const code = String(body.code || '');
    if (!code.trim()) {
      return res.status(400).json({ error: 'Código vacío' });
    }
    if (Buffer.byteLength(code, 'utf8') > 1_500_000) {
      return res.status(400).json({ error: 'Código demasiado grande (máx. ~1.5 MB)' });
    }

    const preset = ['Low', 'Medium', 'High', 'Ultra'].includes(body.preset)
      ? body.preset
      : 'Medium';

    const config = {
      preset,
      stringEncryption: body.stringEncryption !== false,
      controlFlowFlattening: body.controlFlowFlattening !== false,
      nameMangling: body.nameMangling !== false,
      antiSandbox: body.antiSandbox === true || preset === 'High' || preset === 'Ultra',
      compact: body.compact === true,
      debugLogging: false
    };

    // Honor explicit toggles over preset when provided
    if (typeof body.stringEncryption === 'boolean') config.stringEncryption = body.stringEncryption;
    if (typeof body.controlFlowFlattening === 'boolean') config.controlFlowFlattening = body.controlFlowFlattening;
    if (typeof body.nameMangling === 'boolean') config.nameMangling = body.nameMangling;
    if (typeof body.antiSandbox === 'boolean') config.antiSandbox = body.antiSandbox;

    const obfuscator = new Qyrexobf(config);
    const result = obfuscator.obfuscate(code);

    res.json({
      code: result.code,
      summary: result.summary || null,
      preset,
      config: {
        stringEncryption: config.stringEncryption,
        controlFlowFlattening: config.controlFlowFlattening,
        nameMangling: config.nameMangling,
        antiSandbox: config.antiSandbox,
        compact: config.compact
      }
    });
  } catch (e) {
    console.error('[Qyrexobf] API error:', e);
    res.status(500).json({ error: e.message || 'Error al ofuscar' });
  }
});

app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log('Qyrexobf listening on 0.0.0.0:' + PORT);
});
